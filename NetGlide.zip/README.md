
  # Futuristic Browser Project

  This is a code bundle for Futuristic Browser Project. The original project is available at https://www.figma.com/design/fUtk2n8xpsnMAbvOdN5SWj/Futuristic-Browser-Project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  